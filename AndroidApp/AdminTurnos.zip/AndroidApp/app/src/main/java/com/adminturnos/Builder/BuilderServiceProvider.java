package com.adminturnos.Builder;

import com.adminturnos.ObjectInterfaces.ServiceProvider;

import org.json.JSONException;
import org.json.JSONObject;

public class BuilderServiceProvider implements ObjectBuilder<ServiceProvider> {

    @Override
    public ServiceProvider build(JSONObject json) throws JSONException {
        return null;
    }
}
