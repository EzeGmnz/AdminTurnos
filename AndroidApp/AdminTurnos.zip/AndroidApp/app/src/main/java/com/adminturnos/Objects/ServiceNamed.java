package com.adminturnos.Objects;

import com.adminturnos.ObjectInterfaces.Service;

/**
 *
 */
public class ServiceNamed implements Service {

    /**
     * Default constructor
     */
    public ServiceNamed() {
    }

}