package com.adminturnos.Functionality;

/**
 *
 */
public class AppointmentBookingImp implements AppointmentBooking {

    /**
     * Default constructor
     */
    public AppointmentBookingImp() {
    }

}