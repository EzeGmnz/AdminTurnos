package com.adminturnos.Functionality;

/**
 *
 */
public interface AppointmentBooking {

}