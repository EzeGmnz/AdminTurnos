package com.adminturnos.ObjectInterfaces;

/**
 *
 */
public interface Place {


}