package com.adminturnos.Objects;

import com.adminturnos.ObjectInterfaces.Division;

/**
 *
 */
public class Division10min implements Division {

    /**
     * Default constructor
     */
    public Division10min() {
    }

}