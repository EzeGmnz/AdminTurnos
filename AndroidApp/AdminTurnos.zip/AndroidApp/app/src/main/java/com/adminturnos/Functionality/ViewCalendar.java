package com.adminturnos.Functionality;

/**
 *
 */
public interface ViewCalendar {

}