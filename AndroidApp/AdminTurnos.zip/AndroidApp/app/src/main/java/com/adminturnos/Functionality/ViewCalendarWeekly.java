package com.adminturnos.Functionality;

/**
 *
 */
public class ViewCalendarWeekly implements ViewCalendar {

    /**
     * Default constructor
     */
    public ViewCalendarWeekly() {
    }

}