package com.adminturnos.ObjectInterfaces;

import com.adminturnos.Objects.Place;

/**
 *
 */
public interface Job {

    public String getId();

    public Place getPlace();
}