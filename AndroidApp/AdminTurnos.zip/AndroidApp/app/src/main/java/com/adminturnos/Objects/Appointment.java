package com.adminturnos.Objects;

/**
 *
 */
public class Appointment {

    /**
     * Default constructor
     */
    public Appointment() {
    }


}