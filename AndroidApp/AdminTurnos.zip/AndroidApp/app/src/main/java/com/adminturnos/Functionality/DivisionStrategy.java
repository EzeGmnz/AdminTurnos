package com.adminturnos.Functionality;

/**
 *
 */
public class DivisionStrategy {

    /**
     * Default constructor
     */
    public DivisionStrategy() {
    }

}