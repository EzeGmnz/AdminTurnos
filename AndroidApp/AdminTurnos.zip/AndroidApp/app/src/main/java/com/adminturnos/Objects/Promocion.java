package com.adminturnos.Objects;

/**
 *
 */
public class Promocion {

    /**
     * Default constructor
     */
    public Promocion() {
    }

}