package com.adminturnos.Functionality;

/**
 *
 */
public class AppointmentViewingImp implements AppointmentViewing {

    /**
     * Default constructor
     */
    public AppointmentViewingImp() {
    }

}