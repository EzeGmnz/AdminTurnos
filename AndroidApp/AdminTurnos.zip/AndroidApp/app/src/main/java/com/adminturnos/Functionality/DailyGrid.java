package com.adminturnos.Functionality;

/**
 *
 */
public class DailyGrid {

    /**
     * Default constructor
     */
    public DailyGrid() {
    }


}