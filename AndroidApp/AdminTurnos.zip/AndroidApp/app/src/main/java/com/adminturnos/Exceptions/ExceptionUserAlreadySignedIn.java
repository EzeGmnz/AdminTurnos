package com.adminturnos.Exceptions;

public class ExceptionUserAlreadySignedIn extends Exception {

    public ExceptionUserAlreadySignedIn(String a) {
        super(a);

    }

}
