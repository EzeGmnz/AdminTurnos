package com.adminturnos.Functionality;

/**
 *
 */
public class AppointmentManager {

    /**
     * Default constructor
     */
    public AppointmentManager() {
    }

}