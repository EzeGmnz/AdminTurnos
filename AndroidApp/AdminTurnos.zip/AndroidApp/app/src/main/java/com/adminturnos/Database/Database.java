package com.adminturnos.Database;

public interface Database {

    public String getUrl();

}