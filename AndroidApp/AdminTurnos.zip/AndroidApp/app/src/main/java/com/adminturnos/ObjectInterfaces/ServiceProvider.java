package com.adminturnos.ObjectInterfaces;

/**
 *
 */
public interface ServiceProvider {


}