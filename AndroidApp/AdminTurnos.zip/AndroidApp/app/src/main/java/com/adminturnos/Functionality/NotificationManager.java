package com.adminturnos.Functionality;

/**
 *
 */
public class NotificationManager {

    /**
     * Default constructor
     */
    public NotificationManager() {
    }

}