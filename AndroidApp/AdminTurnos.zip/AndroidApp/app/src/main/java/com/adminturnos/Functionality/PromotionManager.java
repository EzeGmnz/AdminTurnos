package com.adminturnos.Functionality;

/**
 *
 */
public class PromotionManager {

    /**
     * Default constructor
     */
    public PromotionManager() {
    }


}