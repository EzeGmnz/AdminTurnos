package com.adminturnos.Functionality;

/**
 *
 */
public class ViewCalendarMonthly implements ViewCalendar {

    /**
     * Default constructor
     */
    public ViewCalendarMonthly() {
    }

}