package com.adminturnos.Listeners;

import com.adminturnos.ObjectInterfaces.ServiceProvider;

public interface ListenerAuthenticator {

    public void onComplete(int resultCode);
}
