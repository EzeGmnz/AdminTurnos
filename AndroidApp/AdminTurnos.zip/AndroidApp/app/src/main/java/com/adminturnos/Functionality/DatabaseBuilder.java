package com.adminturnos.Functionality;

/**
 *
 */
public class DatabaseBuilder {

    /**
     * Default constructor
     */
    public DatabaseBuilder() {
    }


}