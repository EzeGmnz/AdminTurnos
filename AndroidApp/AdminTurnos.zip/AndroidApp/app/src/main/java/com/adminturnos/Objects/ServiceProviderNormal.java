package com.adminturnos.Objects;

import com.adminturnos.ObjectInterfaces.ServiceProvider;

/**
 *
 */
public class ServiceProviderNormal implements ServiceProvider {

    /**
     * Default constructor
     */
    public ServiceProviderNormal() {
    }


}