package com.adminturnos.Functionality;

/**
 *
 */
public class ViewCalendarDaily implements ViewCalendar {

    /**
     * Default constructor
     */
    public ViewCalendarDaily() {
    }

}