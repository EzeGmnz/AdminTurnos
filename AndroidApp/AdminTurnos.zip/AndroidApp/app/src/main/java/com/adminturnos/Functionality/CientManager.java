package com.adminturnos.Functionality;

/**
 *
 */
public class CientManager {

    /**
     * Default constructor
     */
    public CientManager() {
    }


}