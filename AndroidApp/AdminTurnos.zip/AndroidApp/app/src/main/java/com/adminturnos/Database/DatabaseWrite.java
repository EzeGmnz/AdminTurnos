package com.adminturnos.Database;

/**
 *
 */
public interface DatabaseWrite {


}