package com.adminturnos.Exceptions;

public class ExceptionEmailInUse extends Exception {

    public ExceptionEmailInUse(String a) {
        super(a);
    }

}
