package com.adminturnos.Functionality;

/**
 *
 */
public class ServicesManager {

    /**
     * Default constructor
     */
    public ServicesManager() {
    }


}