package com.adminturnos.Objects;

/**
 *
 */
public class Rubro {

    /**
     * Default constructor
     */
    public Rubro() {
    }


}