package com.adminturnos.Builder;

import org.json.JSONException;
import org.json.JSONObject;

public class BuilderNormalClient implements ObjectBuilder {

    @Override
    public Object build(JSONObject json) throws JSONException {
        return null;
    }
}
