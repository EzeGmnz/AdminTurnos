package com.adminturnos.Objects;

import com.adminturnos.ObjectInterfaces.Client;

/**
 *
 */
public class ClientNormal implements Client {

    /**
     * Default constructor
     */
    public ClientNormal() {
    }

}