package com.adminturnos.Objects;

/**
 *
 */
public class Calendar {

    /**
     * Default constructor
     */
    public Calendar() {
    }


}